import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

// ─────────────────────────────────────────────
// APP ROOT
// ─────────────────────────────────────────────
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Static Resources App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'CustomFont',
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C63FF),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F6FB),
      ),
      home: const GalleryScreen(),
    );
  }
}

// ─────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────
class ImageItem {
  final String path;
  final String title;
  final String subtitle;
  final Color accent;

  const ImageItem({
    required this.path,
    required this.title,
    required this.subtitle,
    required this.accent,
  });
}

const List<ImageItem> galleryItems = [
  ImageItem(
    path: 'assets/images/image1.png',
    title: 'Nature',
    subtitle: 'Explore the wild outdoors',
    accent: Color(0xFF4CAF50),
  ),
  ImageItem(
    path: 'assets/images/image2.png',
    title: 'Architecture',
    subtitle: 'Beauty in structure & form',
    accent: Color(0xFF2196F3),
  ),
  ImageItem(
    path: 'assets/images/image3.png',
    title: 'Abstract',
    subtitle: 'Art beyond the ordinary',
    accent: Color(0xFFE91E63),
  ),
];

// ─────────────────────────────────────────────
// SCREEN
// ─────────────────────────────────────────────
class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen>
    with SingleTickerProviderStateMixin {
  bool _isGrid = false;
  late final AnimationController _fadeCtrl;
  late final Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _toggleLayout() {
    setState(() => _isGrid = !_isGrid);
    _fadeCtrl
      ..reset()
      ..forward();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      // ── AppBar ──────────────────────────────
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          'My Gallery',
          style: TextStyle(
            fontFamily: 'CustomFont',
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: scheme.onSurface,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: IconButton(
              style: IconButton.styleFrom(
                backgroundColor: scheme.primaryContainer,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              icon: Icon(
                _isGrid ? Icons.view_list_rounded : Icons.grid_view_rounded,
                color: scheme.primary,
              ),
              onPressed: _toggleLayout,
              tooltip: _isGrid ? 'List view' : 'Grid view',
            ),
          ),
        ],
      ),

      // ── Body ────────────────────────────────
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header block
            _HeaderBlock(),
            const SizedBox(height: 28),

            // Gallery label
            Text(
              'Featured Images',
              style: TextStyle(
                fontFamily: 'CustomFont',
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: scheme.onSurface,
              ),
            ),
            const SizedBox(height: 14),

            // Cards
            FadeTransition(
              opacity: _fadeAnim,
              child: _isGrid ? _GridLayout() : _ListLayout(),
            ),

            const SizedBox(height: 32),

            // Font showcase
            _FontShowcase(),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// HEADER BLOCK
// ─────────────────────────────────────────────
class _HeaderBlock extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [scheme.primary, scheme.tertiary],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: scheme.primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Static Resources',
            style: TextStyle(
              fontFamily: 'CustomFont',
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Images · Fonts · Assets — all in one place',
            style: TextStyle(
              fontFamily: 'CustomFont',
              fontSize: 14,
              color: Colors.white.withOpacity(0.85),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _Chip(icon: Icons.image_rounded, label: '3 Images'),
              const SizedBox(width: 10),
              _Chip(icon: Icons.font_download_rounded, label: 'Custom Font'),
            ],
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Chip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.white),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'CustomFont',
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// LIST LAYOUT
// ─────────────────────────────────────────────
class _ListLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: galleryItems
          .map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _ListCard(item: item),
              ))
          .toList(),
    );
  }
}

class _ListCard extends StatelessWidget {
  final ImageItem item;
  const _ListCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Image
          ClipRRect(
            borderRadius: const BorderRadius.horizontal(left: Radius.circular(20)),
            child: Image.asset(
              item.path,
              width: 120,
              height: 120,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _ErrorBox(size: 120),
            ),
          ),
          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 32,
                    height: 4,
                    decoration: BoxDecoration(
                      color: item.accent,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    item.title,
                    style: const TextStyle(
                      fontFamily: 'CustomFont',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item.subtitle,
                    style: TextStyle(
                      fontFamily: 'CustomFont',
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Arrow
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Icon(Icons.arrow_forward_ios_rounded,
                size: 16, color: item.accent),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// GRID LAYOUT
// ─────────────────────────────────────────────
class _GridLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: galleryItems.map((item) => _GridCard(item: item)).toList(),
    );
  }
}

class _GridCard extends StatelessWidget {
  final ImageItem item;
  const _GridCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.07),
            blurRadius: 14,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              item.path,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _ErrorBox(size: double.infinity),
            ),
            // Gradient overlay
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.7),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      item.title,
                      style: const TextStyle(
                        fontFamily: 'CustomFont',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      item.subtitle,
                      style: TextStyle(
                        fontFamily: 'CustomFont',
                        fontSize: 10,
                        color: Colors.white.withOpacity(0.8),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
            // Accent dot
            Positioned(
              top: 10,
              right: 10,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: item.accent,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: item.accent.withOpacity(0.5), blurRadius: 6)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// FONT SHOWCASE
// ─────────────────────────────────────────────
class _FontShowcase extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.font_download_rounded, color: scheme.primary, size: 20),
              const SizedBox(width: 8),
              Text(
                'Custom Font Preview',
                style: TextStyle(
                  fontFamily: 'CustomFont',
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: scheme.primary,
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          _FontRow(label: 'Bold 28',
              style: const TextStyle(fontFamily: 'CustomFont', fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _FontRow(label: 'SemiBold 20',
              style: const TextStyle(fontFamily: 'CustomFont', fontSize: 20, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          _FontRow(label: 'Regular 16',
              style: const TextStyle(fontFamily: 'CustomFont', fontSize: 16)),
          const SizedBox(height: 8),
          _FontRow(label: 'Light 13',
              style: const TextStyle(fontFamily: 'CustomFont', fontSize: 13, fontWeight: FontWeight.w300)),
        ],
      ),
    );
  }
}

class _FontRow extends StatelessWidget {
  final String label;
  final TextStyle style;
  const _FontRow({required this.label, required this.style});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        SizedBox(
          width: 100,
          child: Text(
            label,
            style: const TextStyle(fontSize: 10, color: Colors.grey),
          ),
        ),
        Expanded(
          child: Text('The quick brown fox', style: style),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
// ERROR PLACEHOLDER
// ─────────────────────────────────────────────
class _ErrorBox extends StatelessWidget {
  final double size;
  const _ErrorBox({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size == double.infinity ? null : size,
      height: size == double.infinity ? null : size,
      color: Colors.grey[100],
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.broken_image_rounded, size: 32, color: Colors.grey),
          SizedBox(height: 6),
          Text('No image', style: TextStyle(fontSize: 11, color: Colors.grey)),
        ],
      ),
    );
  }
}
